// Please keep keys lowercase!
export default {
  'https://reactjs.org': {
    'pt-br': 'https://pt-br.reactjs.org',
    // other languages...
  },
  // other links...
};
